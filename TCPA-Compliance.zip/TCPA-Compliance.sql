-- MariaDB dump 10.19  Distrib 10.5.22-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: asterisk
-- ------------------------------------------------------
-- Server version	10.5.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vicidial_call_times`
--

DROP TABLE IF EXISTS `vicidial_call_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vicidial_call_times` (
  `call_time_id` varchar(10) NOT NULL,
  `call_time_name` varchar(30) NOT NULL,
  `call_time_comments` varchar(255) DEFAULT '',
  `ct_default_start` smallint(4) unsigned NOT NULL DEFAULT 900,
  `ct_default_stop` smallint(4) unsigned NOT NULL DEFAULT 2100,
  `ct_sunday_start` smallint(4) unsigned DEFAULT 0,
  `ct_sunday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_monday_start` smallint(4) unsigned DEFAULT 0,
  `ct_monday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_tuesday_start` smallint(4) unsigned DEFAULT 0,
  `ct_tuesday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_wednesday_start` smallint(4) unsigned DEFAULT 0,
  `ct_wednesday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_thursday_start` smallint(4) unsigned DEFAULT 0,
  `ct_thursday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_friday_start` smallint(4) unsigned DEFAULT 0,
  `ct_friday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_saturday_start` smallint(4) unsigned DEFAULT 0,
  `ct_saturday_stop` smallint(4) unsigned DEFAULT 0,
  `ct_state_call_times` text DEFAULT NULL,
  `default_afterhours_filename_override` varchar(255) DEFAULT '',
  `sunday_afterhours_filename_override` varchar(255) DEFAULT '',
  `monday_afterhours_filename_override` varchar(255) DEFAULT '',
  `tuesday_afterhours_filename_override` varchar(255) DEFAULT '',
  `wednesday_afterhours_filename_override` varchar(255) DEFAULT '',
  `thursday_afterhours_filename_override` varchar(255) DEFAULT '',
  `friday_afterhours_filename_override` varchar(255) DEFAULT '',
  `saturday_afterhours_filename_override` varchar(255) DEFAULT '',
  `user_group` varchar(20) DEFAULT '---ALL---',
  `ct_holidays` text DEFAULT NULL,
  PRIMARY KEY (`call_time_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vicidial_call_times`
--

LOCK TABLES `vicidial_call_times` WRITE;
/*!40000 ALTER TABLE `vicidial_call_times` DISABLE KEYS */;
INSERT INTO `vicidial_call_times` VALUES ('24hours','default 24 hours calling','',0,2400,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|'),('9am-9pm','default 10am to 10pm calling','',1000,2200,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|MARTINLUTHERKINGJR|CONFEDERATEMEMORIALDAY|MARDIGRAS|WASHINGTONSDAY|GOODFRIDAY|CONFEDERATEALABAMA|RHODEISLANDINDEPENDENCE|VICTORYDAY|MEMORIALDAY|JEFFERSONDAVISBIRTHDAY|FLAGDAY|JUNETEENTHLA|LEGALHOLIDAY|INDEPENDENCEDAY|PIONEERDAY|ACADIANDAY|HUEYPLONGDAY|LABORDAY|COLUMBUSDAY|ALLSAINTSDAY|VETERANSDAYOBSERVED|VETERANSDAY|VETERANSDAYOBSERVED_RI|THANKSGIVING|CHRISTMAS|DATAFTERCHRISTMAS|'),('9am-5pm','default 9am to 5pm calling','',900,1700,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|MARTINLUTHERKINGJR|CONFEDERATEMEMORIALDAY|MARDIGRAS|WASHINGTONSDAY|GOODFRIDAY|CONFEDERATEALABAMA|RHODEISLANDINDEPENDENCE|VICTORYDAY|MEMORIALDAY|JEFFERSONDAVISBIRTHDAY|FLAGDAY|JUNETEENTHLA|LEGALHOLIDAY|INDEPENDENCEDAY|PIONEERDAY|ACADIANDAY|HUEYPLONGDAY|LABORDAY|COLUMBUSDAY|ALLSAINTSDAY|VETERANSDAYOBSERVED|VETERANSDAY|VETERANSDAYOBSERVED_RI|THANKSGIVING|CHRISTMAS|DATAFTERCHRISTMAS|'),('12pm-5pm','default 12pm to 5pm calling','',1200,1700,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|MARTINLUTHERKINGJR|CONFEDERATEMEMORIALDAY|MARDIGRAS|WASHINGTONSDAY|GOODFRIDAY|CONFEDERATEALABAMA|RHODEISLANDINDEPENDENCE|VICTORYDAY|MEMORIALDAY|JEFFERSONDAVISBIRTHDAY|FLAGDAY|JUNETEENTHLA|LEGALHOLIDAY|INDEPENDENCEDAY|PIONEERDAY|ACADIANDAY|HUEYPLONGDAY|LABORDAY|COLUMBUSDAY|ALLSAINTSDAY|VETERANSDAYOBSERVED|VETERANSDAY|VETERANSDAYOBSERVED_RI|THANKSGIVING|CHRISTMAS|DATAFTERCHRISTMAS|'),('12pm-9pm','default 12pm to 9pm calling','',1200,2100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|MARTINLUTHERKINGJR|CONFEDERATEMEMORIALDAY|MARDIGRAS|WASHINGTONSDAY|GOODFRIDAY|CONFEDERATEALABAMA|RHODEISLANDINDEPENDENCE|VICTORYDAY|MEMORIALDAY|JEFFERSONDAVISBIRTHDAY|FLAGDAY|JUNETEENTHLA|LEGALHOLIDAY|INDEPENDENCEDAY|PIONEERDAY|ACADIANDAY|HUEYPLONGDAY|LABORDAY|COLUMBUSDAY|ALLSAINTSDAY|VETERANSDAYOBSERVED|VETERANSDAY|VETERANSDAYOBSERVED_RI|THANKSGIVING|CHRISTMAS|DATAFTERCHRISTMAS|'),('5pm-9pm','default 5pm to 9pm calling','',1700,2100,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'|alabama|illinois|indiana|kentucky|louisiana|massachuse|mississipp|nebraska|nevada|pennsylvan|rhodeislan|sdakota|tennessee|texas|utah|washington|wyoming|','','','','','','','','','---ALL---','|NEWYEARS|MARTINLUTHERKINGJR|CONFEDERATEMEMORIALDAY|MARDIGRAS|WASHINGTONSDAY|GOODFRIDAY|CONFEDERATEALABAMA|RHODEISLANDINDEPENDENCE|VICTORYDAY|MEMORIALDAY|JEFFERSONDAVISBIRTHDAY|FLAGDAY|JUNETEENTHLA|LEGALHOLIDAY|INDEPENDENCEDAY|PIONEERDAY|ACADIANDAY|HUEYPLONGDAY|LABORDAY|COLUMBUSDAY|ALLSAINTSDAY|VETERANSDAYOBSERVED|VETERANSDAY|VETERANSDAYOBSERVED_RI|THANKSGIVING|CHRISTMAS|DATAFTERCHRISTMAS|');
/*!40000 ALTER TABLE `vicidial_call_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vicidial_call_time_holidays`
--

DROP TABLE IF EXISTS `vicidial_call_time_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vicidial_call_time_holidays` (
  `holiday_id` varchar(30) NOT NULL,
  `holiday_name` varchar(100) NOT NULL,
  `holiday_comments` varchar(255) DEFAULT '',
  `holiday_date` date DEFAULT NULL,
  `holiday_status` enum('ACTIVE','INACTIVE','EXPIRED') DEFAULT 'INACTIVE',
  `ct_default_start` smallint(4) unsigned NOT NULL DEFAULT 900,
  `ct_default_stop` smallint(4) unsigned NOT NULL DEFAULT 2100,
  `default_afterhours_filename_override` varchar(255) DEFAULT '',
  `user_group` varchar(20) DEFAULT '---ALL---',
  PRIMARY KEY (`holiday_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vicidial_call_time_holidays`
--

LOCK TABLES `vicidial_call_time_holidays` WRITE;
/*!40000 ALTER TABLE `vicidial_call_time_holidays` DISABLE KEYS */;
INSERT INTO `vicidial_call_time_holidays` VALUES ('NEWYEARS','New Years Day','','2024-01-01','EXPIRED',0,0,'','---ALL---'),('MARTINLUTHERKINGJR','Martin Luther King Jr. Day','','2024-01-15','ACTIVE',0,0,'','---ALL---'),('WASHINGTONSDAY','Washingtons Day','','2024-02-19','ACTIVE',0,0,'','---ALL---'),('MARDIGRAS','Mardi Gras','','2024-02-13','ACTIVE',0,0,'','---ALL---'),('GOODFRIDAY','Good Friday','','2024-03-19','ACTIVE',0,0,'','---ALL---'),('CONFEDERATEMEMORIALDAY','Confederate Memorial Day Mississippi','','2024-01-29','ACTIVE',0,0,'','---ALL---'),('CONFEDERATEALABAMA','Conferate Memorial Day Alabama','','2024-04-22','ACTIVE',0,0,'','---ALL---'),('RHODEISLANDINDEPENDENCE','Rhode Island Independence day','','2024-05-04','ACTIVE',0,0,'','---ALL---'),('MEMORIALDAY','Memorial Day','','2024-05-27','ACTIVE',0,0,'','---ALL---'),('JEFFERSONDAVISBIRTHDAY','Jefferson Davis Birthday','','2024-06-03','ACTIVE',0,0,'','---ALL---'),('FLAGDAY','Flag Day','','2024-06-14','ACTIVE',0,0,'','---ALL---'),('JUNETEENTHLA','Juneteenth Day Louisiana','','2024-06-19','ACTIVE',0,0,'','---ALL---'),('LEGALHOLIDAY','Legal Holiday - Louisiana','','2024-07-03','ACTIVE',0,0,'','---ALL---'),('INDEPENDENCEDAY','Independence Day','','2024-07-04','ACTIVE',0,0,'','---ALL---'),('PIONEERDAY','Pioneer Day','','2024-07-24','ACTIVE',0,0,'','---ALL---'),('VICTORYDAY','Victory Day','','2024-05-08','ACTIVE',0,0,'','---ALL---'),('HUEYPLONGDAY','Huey P. Long Day','','2024-08-30','ACTIVE',0,0,'','---ALL---'),('LABORDAY','Labor Day','','2024-09-02','ACTIVE',0,0,'','---ALL---'),('COLUMBUSDAY','Columbus Day','','2024-10-14','ACTIVE',0,0,'','---ALL---'),('ALLSAINTSDAY','All Saints Day','','2024-11-01','ACTIVE',0,0,'','---ALL---'),('VETERANSDAYOBSERVED','Veterans Day Observed','','2024-11-10','ACTIVE',0,0,'','---ALL---'),('VETERANSDAY','Veterans Day','','2024-11-11','ACTIVE',0,0,'','---ALL---'),('VETERANSDAYOBSERVED_RI','Veterans Day Observed - Rhode Island','','2024-11-13','ACTIVE',0,0,'','---ALL---'),('THANKSGIVING','Thanksgiving Day','','2024-11-28','ACTIVE',0,0,'','---ALL---'),('ACADIANDAY','Acadian Day','','2024-08-15','ACTIVE',0,0,'','---ALL---'),('CHRISTMAS','Christmas Day','','2024-12-25','ACTIVE',0,0,'','---ALL---'),('DATAFTERCHRISTMAS','Day After Christmas','','2024-12-26','ACTIVE',0,0,'','---ALL---');
/*!40000 ALTER TABLE `vicidial_call_time_holidays` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-14 14:03:24
